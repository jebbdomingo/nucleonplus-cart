<?php
/**
 * Nucleon Plus
 *
 * @package     Nucleon Plus
 * @copyright   Copyright (C) 2016 - 2019 Nucleon + co. (http://www.nucleonplus.com)
 * @link        https://github.com/jebbdomingo/nucleonplus for the canonical source repository
 */

require_once __DIR__.'/helper.php';

class com_cartInstallerScript extends JoomlatoolsInstallerHelper
{
}
